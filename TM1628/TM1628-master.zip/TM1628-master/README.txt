TM1628 library
--------------
Vasyl Yudin
Email: vasyl(dot)yudin(at)gmail(dot)com
URL: github TM1628

A library for interacting an arduino with a TM1628.

Includes:
- Support for the TM1628;
- Helper method for displaying time;
- Reading simultaneous button presses;
- Support for dimming the display and LEDs;
- Support for method 'print';

USAGE NOTES
-----------

Just put the files on a TM1628 directory under "arduino/libraries" on your arduino IDE instalation
