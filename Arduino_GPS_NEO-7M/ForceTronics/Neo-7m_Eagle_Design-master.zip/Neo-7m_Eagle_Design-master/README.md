# Neo-7m_Eagle_Design
Reference or evaluation PCB design for the ublox Neo-7m GNSS / GPS module

Free to use and modify at your own risk
