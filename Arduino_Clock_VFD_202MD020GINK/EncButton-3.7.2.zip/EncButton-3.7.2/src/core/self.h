#pragma once

extern void* EB_self;